--
-- PostgreSQL database dump
--

\restrict f8ZEbBQeGTb3TzLWvVsH9xjfH62fSHQsc1jWGm1NPOM1CJDcnubUIcWgz3cBec5

-- Dumped from database version 14.24 (Homebrew)
-- Dumped by pg_dump version 14.24 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_cohort_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_timetable_entries DROP CONSTRAINT IF EXISTS user_timetable_entries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_timetable_entries DROP CONSTRAINT IF EXISTS user_timetable_entries_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_timetable_entries DROP CONSTRAINT IF EXISTS user_timetable_entries_faculty_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_profiles DROP CONSTRAINT IF EXISTS user_profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_academic_settings DROP CONSTRAINT IF EXISTS user_academic_settings_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.topic_learning_progress DROP CONSTRAINT IF EXISTS topic_learning_progress_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.topic_learning_progress DROP CONSTRAINT IF EXISTS topic_learning_progress_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.student_documents DROP CONSTRAINT IF EXISTS student_documents_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.student_documents DROP CONSTRAINT IF EXISTS student_documents_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.revision_sessions DROP CONSTRAINT IF EXISTS revision_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.revision_sessions DROP CONSTRAINT IF EXISTS revision_sessions_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.quizzes DROP CONSTRAINT IF EXISTS quizzes_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.quiz_attempts DROP CONSTRAINT IF EXISTS quiz_attempts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.quiz_attempts DROP CONSTRAINT IF EXISTS quiz_attempts_quiz_id_fkey;
ALTER TABLE IF EXISTS ONLY public.official_timetable_templates DROP CONSTRAINT IF EXISTS official_timetable_templates_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.official_timetable_templates DROP CONSTRAINT IF EXISTS official_timetable_templates_faculty_id_fkey;
ALTER TABLE IF EXISTS ONLY public.official_timetable_templates DROP CONSTRAINT IF EXISTS official_timetable_templates_cohort_id_fkey;
ALTER TABLE IF EXISTS ONLY public.official_documents DROP CONSTRAINT IF EXISTS official_documents_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.migration_staged_records DROP CONSTRAINT IF EXISTS migration_staged_records_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lectures DROP CONSTRAINT IF EXISTS lectures_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lectures DROP CONSTRAINT IF EXISTS lectures_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lectures DROP CONSTRAINT IF EXISTS lectures_faculty_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_ingestion_anomalies DROP CONSTRAINT IF EXISTS document_ingestion_anomalies_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_ingestion_anomalies DROP CONSTRAINT IF EXISTS document_ingestion_anomalies_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.document_chunks DROP CONSTRAINT IF EXISTS document_chunks_document_id_fkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_topics DROP CONSTRAINT IF EXISTS curriculum_topics_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_topics DROP CONSTRAINT IF EXISTS curriculum_topics_module_id_fkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_subjects DROP CONSTRAINT IF EXISTS curriculum_subjects_default_faculty_id_fkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_subjects DROP CONSTRAINT IF EXISTS curriculum_subjects_cohort_id_fkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_modules DROP CONSTRAINT IF EXISTS curriculum_modules_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cohorts DROP CONSTRAINT IF EXISTS cohorts_institution_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_audit_log DROP CONSTRAINT IF EXISTS attendance_audit_log_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_audit_log DROP CONSTRAINT IF EXISTS attendance_audit_log_subject_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attendance_audit_log DROP CONSTRAINT IF EXISTS attendance_audit_log_lecture_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ai_messages DROP CONSTRAINT IF EXISTS ai_messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ai_conversations DROP CONSTRAINT IF EXISTS ai_conversations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ai_conversations DROP CONSTRAINT IF EXISTS ai_conversations_subject_id_fkey;
DROP TRIGGER IF EXISTS trg_check_user_timetable_overlap ON public.user_timetable_entries;
DROP TRIGGER IF EXISTS trg_check_classroom_double_booking ON public.user_timetable_entries;
DROP INDEX IF EXISTS public.uq_user_timetable_slot;
DROP INDEX IF EXISTS public.idx_timetable_templates_day;
DROP INDEX IF EXISTS public.idx_timetable_entries_date;
DROP INDEX IF EXISTS public.idx_tasks_user_deadline;
DROP INDEX IF EXISTS public.idx_lectures_user_subject;
DROP INDEX IF EXISTS public.idx_lectures_user_date;
DROP INDEX IF EXISTS public.idx_chunks_doc_page;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_timetable_entries DROP CONSTRAINT IF EXISTS user_timetable_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.user_profiles DROP CONSTRAINT IF EXISTS user_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_academic_settings DROP CONSTRAINT IF EXISTS user_academic_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.lectures DROP CONSTRAINT IF EXISTS uq_lecture_user_slot;
ALTER TABLE IF EXISTS ONLY public.topic_learning_progress DROP CONSTRAINT IF EXISTS topic_learning_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.student_documents DROP CONSTRAINT IF EXISTS student_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.revision_sessions DROP CONSTRAINT IF EXISTS revision_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.quizzes DROP CONSTRAINT IF EXISTS quizzes_pkey;
ALTER TABLE IF EXISTS ONLY public.quiz_attempts DROP CONSTRAINT IF EXISTS quiz_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.official_timetable_templates DROP CONSTRAINT IF EXISTS official_timetable_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.official_documents DROP CONSTRAINT IF EXISTS official_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.migration_staged_records DROP CONSTRAINT IF EXISTS migration_staged_records_pkey;
ALTER TABLE IF EXISTS ONLY public.lectures DROP CONSTRAINT IF EXISTS lectures_pkey;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_short_code_key;
ALTER TABLE IF EXISTS ONLY public.institutions DROP CONSTRAINT IF EXISTS institutions_pkey;
ALTER TABLE IF EXISTS ONLY public.faculty DROP CONSTRAINT IF EXISTS faculty_pkey;
ALTER TABLE IF EXISTS ONLY public.faculty DROP CONSTRAINT IF EXISTS faculty_name_key;
ALTER TABLE IF EXISTS ONLY public.document_ingestion_anomalies DROP CONSTRAINT IF EXISTS document_ingestion_anomalies_pkey;
ALTER TABLE IF EXISTS ONLY public.document_chunks DROP CONSTRAINT IF EXISTS document_chunks_pkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_topics DROP CONSTRAINT IF EXISTS curriculum_topics_pkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_subjects DROP CONSTRAINT IF EXISTS curriculum_subjects_pkey;
ALTER TABLE IF EXISTS ONLY public.curriculum_subjects DROP CONSTRAINT IF EXISTS curriculum_subjects_code_key;
ALTER TABLE IF EXISTS ONLY public.curriculum_modules DROP CONSTRAINT IF EXISTS curriculum_modules_pkey;
ALTER TABLE IF EXISTS ONLY public.cohorts DROP CONSTRAINT IF EXISTS cohorts_pkey;
ALTER TABLE IF EXISTS ONLY public.classrooms DROP CONSTRAINT IF EXISTS classrooms_pkey;
ALTER TABLE IF EXISTS ONLY public.classrooms DROP CONSTRAINT IF EXISTS classrooms_name_key;
ALTER TABLE IF EXISTS ONLY public.attendance_audit_log DROP CONSTRAINT IF EXISTS attendance_audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_messages DROP CONSTRAINT IF EXISTS ai_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.ai_conversations DROP CONSTRAINT IF EXISTS ai_conversations_pkey;
ALTER TABLE IF EXISTS public.migration_staged_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.document_ingestion_anomalies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attendance_audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_timetable_entries;
DROP TABLE IF EXISTS public.user_profiles;
DROP TABLE IF EXISTS public.user_academic_settings;
DROP TABLE IF EXISTS public.topic_learning_progress;
DROP TABLE IF EXISTS public.tasks;
DROP TABLE IF EXISTS public.student_documents;
DROP TABLE IF EXISTS public.revision_sessions;
DROP TABLE IF EXISTS public.quizzes;
DROP TABLE IF EXISTS public.quiz_attempts;
DROP TABLE IF EXISTS public.official_timetable_templates;
DROP TABLE IF EXISTS public.official_documents;
DROP SEQUENCE IF EXISTS public.migration_staged_records_id_seq;
DROP TABLE IF EXISTS public.migration_staged_records;
DROP TABLE IF EXISTS public.lectures;
DROP TABLE IF EXISTS public.institutions;
DROP TABLE IF EXISTS public.faculty;
DROP SEQUENCE IF EXISTS public.document_ingestion_anomalies_id_seq;
DROP TABLE IF EXISTS public.document_ingestion_anomalies;
DROP TABLE IF EXISTS public.document_chunks;
DROP TABLE IF EXISTS public.curriculum_topics;
DROP TABLE IF EXISTS public.curriculum_subjects;
DROP TABLE IF EXISTS public.curriculum_modules;
DROP TABLE IF EXISTS public.cohorts;
DROP TABLE IF EXISTS public.classrooms;
DROP SEQUENCE IF EXISTS public.attendance_audit_log_id_seq;
DROP TABLE IF EXISTS public.attendance_audit_log;
DROP TABLE IF EXISTS public.ai_messages;
DROP TABLE IF EXISTS public.ai_conversations;
DROP FUNCTION IF EXISTS public.check_user_timetable_overlap();
DROP FUNCTION IF EXISTS public.check_classroom_double_booking();
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: check_classroom_double_booking(); Type: FUNCTION; Schema: public; Owner: ashutoshrai
--

CREATE FUNCTION public.check_classroom_double_booking() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.classroom IS NOT NULL AND TRIM(NEW.classroom) != '' AND NEW.classroom NOT IN ('UNASSIGNED', 'Cafeteria') THEN
        IF EXISTS (
            SELECT 1 FROM user_timetable_entries
            WHERE specific_date = NEW.specific_date
              AND classroom = NEW.classroom
              AND id != NEW.id
              AND (NEW.start_time, NEW.end_time) OVERLAPS (start_time, end_time)
        ) THEN
            RAISE EXCEPTION 'Classroom double-booking conflict: Room % is already booked between % and % on %', NEW.classroom, NEW.start_time, NEW.end_time, NEW.specific_date;
        END IF;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_classroom_double_booking() OWNER TO ashutoshrai;

--
-- Name: check_user_timetable_overlap(); Type: FUNCTION; Schema: public; Owner: ashutoshrai
--

CREATE FUNCTION public.check_user_timetable_overlap() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM user_timetable_entries
        WHERE user_id = NEW.user_id
          AND specific_date = NEW.specific_date
          AND id != NEW.id
          AND (NEW.start_time, NEW.end_time) OVERLAPS (start_time, end_time)
    ) THEN
        RAISE EXCEPTION 'Timetable overlap conflict: Slot % to % overlaps with an existing slot on %', NEW.start_time, NEW.end_time, NEW.specific_date;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.check_user_timetable_overlap() OWNER TO ashutoshrai;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_conversations; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.ai_conversations (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    subject_id character varying(50),
    title character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.ai_conversations OWNER TO ashutoshrai;

--
-- Name: ai_messages; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.ai_messages (
    id character varying(50) NOT NULL,
    conversation_id character varying(50) NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    sources jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ai_messages_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'assistant'::character varying, 'system'::character varying])::text[])))
);


ALTER TABLE public.ai_messages OWNER TO ashutoshrai;

--
-- Name: attendance_audit_log; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.attendance_audit_log (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    lecture_id character varying(50) NOT NULL,
    subject_id character varying(50) NOT NULL,
    previous_status character varying(20),
    new_status character varying(20) NOT NULL,
    reason text NOT NULL,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attendance_audit_log OWNER TO ashutoshrai;

--
-- Name: attendance_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: ashutoshrai
--

CREATE SEQUENCE public.attendance_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attendance_audit_log_id_seq OWNER TO ashutoshrai;

--
-- Name: attendance_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ashutoshrai
--

ALTER SEQUENCE public.attendance_audit_log_id_seq OWNED BY public.attendance_audit_log.id;


--
-- Name: classrooms; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.classrooms (
    id character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    building character varying(100),
    capacity integer,
    CONSTRAINT classrooms_capacity_check CHECK (((capacity IS NULL) OR (capacity > 0)))
);


ALTER TABLE public.classrooms OWNER TO ashutoshrai;

--
-- Name: cohorts; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.cohorts (
    id character varying(50) NOT NULL,
    institution_id character varying(50),
    name character varying(100) NOT NULL,
    program character varying(150) NOT NULL,
    batch character varying(50) NOT NULL,
    semester character varying(50) NOT NULL,
    sprint character varying(50) DEFAULT 'Sprint 2'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cohorts OWNER TO ashutoshrai;

--
-- Name: curriculum_modules; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.curriculum_modules (
    id character varying(50) NOT NULL,
    subject_id character varying(50) NOT NULL,
    unit_number character varying(20) NOT NULL,
    title character varying(255) NOT NULL,
    hours integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT curriculum_modules_hours_check CHECK ((hours >= 0))
);


ALTER TABLE public.curriculum_modules OWNER TO ashutoshrai;

--
-- Name: curriculum_subjects; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.curriculum_subjects (
    id character varying(50) NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    total_hours integer DEFAULT 45,
    credits integer DEFAULT 3,
    default_faculty_id character varying(50),
    course_type character varying(50) DEFAULT 'Core'::character varying,
    cohort_id character varying(50),
    description text,
    official_doc_url text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT curriculum_subjects_credits_check CHECK ((credits > 0)),
    CONSTRAINT curriculum_subjects_total_hours_check CHECK ((total_hours > 0))
);


ALTER TABLE public.curriculum_subjects OWNER TO ashutoshrai;

--
-- Name: curriculum_topics; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.curriculum_topics (
    id character varying(50) NOT NULL,
    module_id character varying(50) NOT NULL,
    subject_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.curriculum_topics OWNER TO ashutoshrai;

--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.document_chunks (
    id character varying(50) NOT NULL,
    document_id character varying(50) NOT NULL,
    chunk_index integer NOT NULL,
    page_number integer,
    sheet_name character varying(100),
    section_heading character varying(255),
    content_text text NOT NULL,
    token_count integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.document_chunks OWNER TO ashutoshrai;

--
-- Name: document_ingestion_anomalies; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.document_ingestion_anomalies (
    id integer NOT NULL,
    document_id character varying(50) NOT NULL,
    subject_id character varying(50),
    field_name character varying(100) NOT NULL,
    extracted_value text,
    expected_value text,
    severity character varying(20) DEFAULT 'warning'::character varying,
    resolution_status character varying(20) DEFAULT 'pending'::character varying,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT document_ingestion_anomalies_resolution_status_check CHECK (((resolution_status)::text = ANY ((ARRAY['pending'::character varying, 'resolved'::character varying, 'ignored'::character varying])::text[]))),
    CONSTRAINT document_ingestion_anomalies_severity_check CHECK (((severity)::text = ANY ((ARRAY['info'::character varying, 'warning'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE public.document_ingestion_anomalies OWNER TO ashutoshrai;

--
-- Name: document_ingestion_anomalies_id_seq; Type: SEQUENCE; Schema: public; Owner: ashutoshrai
--

CREATE SEQUENCE public.document_ingestion_anomalies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_ingestion_anomalies_id_seq OWNER TO ashutoshrai;

--
-- Name: document_ingestion_anomalies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ashutoshrai
--

ALTER SEQUENCE public.document_ingestion_anomalies_id_seq OWNED BY public.document_ingestion_anomalies.id;


--
-- Name: faculty; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.faculty (
    id character varying(50) NOT NULL,
    name character varying(150) NOT NULL,
    title character varying(100),
    email character varying(150),
    phone character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.faculty OWNER TO ashutoshrai;

--
-- Name: institutions; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.institutions (
    id character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    short_code character varying(50) NOT NULL,
    campus character varying(100),
    academic_year character varying(50) DEFAULT '2026-27'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.institutions OWNER TO ashutoshrai;

--
-- Name: lectures; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.lectures (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    date date NOT NULL,
    subject_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    faculty_id character varying(50),
    faculty_name character varying(150),
    start_time time without time zone,
    end_time time without time zone,
    duration_minutes integer DEFAULT 60,
    status character varying(20) DEFAULT 'attended'::character varying NOT NULL,
    classroom character varying(100),
    notes text,
    what_i_learned text,
    important_concepts jsonb DEFAULT '[]'::jsonb,
    examples_or_code text,
    doubts_or_questions text,
    homework_or_followup text,
    confidence_rating integer,
    needs_revision boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_lecture_time_order CHECK (((start_time IS NULL) OR (end_time IS NULL) OR (end_time > start_time))),
    CONSTRAINT lectures_confidence_rating_check CHECK (((confidence_rating IS NULL) OR ((confidence_rating >= 1) AND (confidence_rating <= 5)))),
    CONSTRAINT lectures_duration_minutes_check CHECK (((duration_minutes >= 15) AND (duration_minutes <= 480))),
    CONSTRAINT lectures_status_check CHECK (((status)::text = ANY ((ARRAY['attended'::character varying, 'absent'::character varying, 'cancelled'::character varying, 'scheduled'::character varying])::text[])))
);


ALTER TABLE public.lectures OWNER TO ashutoshrai;

--
-- Name: migration_staged_records; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.migration_staged_records (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(50) NOT NULL,
    current_record jsonb,
    incoming_record jsonb NOT NULL,
    field_conflicts jsonb DEFAULT '[]'::jsonb,
    status character varying(30) DEFAULT 'pending_review'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT migration_staged_records_status_check CHECK (((status)::text = ANY ((ARRAY['pending_review'::character varying, 'approved'::character varying, 'rejected'::character varying, 'committed'::character varying])::text[])))
);


ALTER TABLE public.migration_staged_records OWNER TO ashutoshrai;

--
-- Name: migration_staged_records_id_seq; Type: SEQUENCE; Schema: public; Owner: ashutoshrai
--

CREATE SEQUENCE public.migration_staged_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migration_staged_records_id_seq OWNER TO ashutoshrai;

--
-- Name: migration_staged_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ashutoshrai
--

ALTER SEQUENCE public.migration_staged_records_id_seq OWNED BY public.migration_staged_records.id;


--
-- Name: official_documents; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.official_documents (
    id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    file_type character varying(20) NOT NULL,
    file_size character varying(50),
    file_hash character varying(64) NOT NULL,
    url text NOT NULL,
    file_path text,
    subject_id character varying(50),
    tags jsonb DEFAULT '[]'::jsonb,
    is_master_plan boolean DEFAULT false,
    extraction_status character varying(30) DEFAULT 'pending'::character varying,
    extractor_version character varying(30) DEFAULT 'v1.0.0'::character varying,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT official_documents_extraction_status_check CHECK (((extraction_status)::text = ANY ((ARRAY['pending'::character varying, 'staged'::character varying, 'completed'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT official_documents_file_type_check CHECK (((file_type)::text = ANY ((ARRAY['pdf'::character varying, 'docx'::character varying, 'xlsx'::character varying, 'txt'::character varying, 'other'::character varying])::text[])))
);


ALTER TABLE public.official_documents OWNER TO ashutoshrai;

--
-- Name: official_timetable_templates; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.official_timetable_templates (
    id character varying(50) NOT NULL,
    cohort_id character varying(50) NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    slot_type character varying(30) NOT NULL,
    subject_id character varying(50),
    faculty_id character varying(50),
    classroom character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_template_duration_matches CHECK ((round((EXTRACT(epoch FROM (end_time - start_time)) / (60)::numeric)) = (duration_minutes)::numeric)),
    CONSTRAINT chk_template_time_order CHECK ((end_time > start_time)),
    CONSTRAINT official_timetable_templates_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT official_timetable_templates_duration_minutes_check CHECK (((duration_minutes >= 15) AND (duration_minutes <= 480))),
    CONSTRAINT official_timetable_templates_slot_type_check CHECK (((slot_type)::text = ANY ((ARRAY['lecture'::character varying, 'lunch_break'::character varying, 'short_break'::character varying, 'free_period'::character varying, 'unassigned'::character varying, 'independent_study'::character varying])::text[])))
);


ALTER TABLE public.official_timetable_templates OWNER TO ashutoshrai;

--
-- Name: quiz_attempts; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.quiz_attempts (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    quiz_id character varying(50) NOT NULL,
    score integer NOT NULL,
    total_questions integer NOT NULL,
    answers jsonb NOT NULL,
    completed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_quiz_score CHECK ((score <= total_questions)),
    CONSTRAINT quiz_attempts_score_check CHECK ((score >= 0)),
    CONSTRAINT quiz_attempts_total_questions_check CHECK ((total_questions > 0))
);


ALTER TABLE public.quiz_attempts OWNER TO ashutoshrai;

--
-- Name: quizzes; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.quizzes (
    id character varying(50) NOT NULL,
    subject_id character varying(50) NOT NULL,
    topic_id character varying(50),
    title character varying(255) NOT NULL,
    questions jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.quizzes OWNER TO ashutoshrai;

--
-- Name: revision_sessions; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.revision_sessions (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    date date NOT NULL,
    subject_id character varying(50) NOT NULL,
    topic_id character varying(50),
    topic_title character varying(255) NOT NULL,
    duration_minutes integer DEFAULT 30,
    confidence_after integer,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT revision_sessions_confidence_after_check CHECK (((confidence_after >= 1) AND (confidence_after <= 5))),
    CONSTRAINT revision_sessions_duration_minutes_check CHECK ((duration_minutes > 0))
);


ALTER TABLE public.revision_sessions OWNER TO ashutoshrai;

--
-- Name: student_documents; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.student_documents (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    file_type character varying(20) NOT NULL,
    file_size character varying(50),
    file_hash character varying(64) NOT NULL,
    subject_id character varying(50),
    file_path text NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT student_documents_file_type_check CHECK (((file_type)::text = ANY ((ARRAY['pdf'::character varying, 'docx'::character varying, 'xlsx'::character varying, 'txt'::character varying, 'other'::character varying])::text[])))
);


ALTER TABLE public.student_documents OWNER TO ashutoshrai;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.tasks (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    subject_id character varying(50),
    deadline date NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'todo'::character varying,
    assessment_category character varying(50),
    estimated_hours numeric(5,2) DEFAULT 1.0,
    actual_hours numeric(5,2) DEFAULT 0.0,
    resource_url text,
    submission_url text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tasks_actual_hours_check CHECK ((actual_hours >= (0)::numeric)),
    CONSTRAINT tasks_estimated_hours_check CHECK ((estimated_hours >= (0)::numeric)),
    CONSTRAINT tasks_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT tasks_status_check CHECK (((status)::text = ANY ((ARRAY['not_started'::character varying, 'todo'::character varying, 'in_progress'::character varying, 'submitted'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.tasks OWNER TO ashutoshrai;

--
-- Name: topic_learning_progress; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.topic_learning_progress (
    user_id character varying(50) NOT NULL,
    topic_id character varying(50) NOT NULL,
    subject_id character varying(50) NOT NULL,
    status character varying(30) DEFAULT 'learning'::character varying,
    confidence_rating integer DEFAULT 3,
    needs_revision boolean DEFAULT false,
    next_revision_date date,
    personal_notes text,
    questions_to_ask text,
    last_revised_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT topic_learning_progress_confidence_rating_check CHECK (((confidence_rating >= 1) AND (confidence_rating <= 5))),
    CONSTRAINT topic_learning_progress_status_check CHECK (((status)::text = ANY ((ARRAY['not_started'::character varying, 'learning'::character varying, 'understood'::character varying, 'needs_revision'::character varying])::text[])))
);


ALTER TABLE public.topic_learning_progress OWNER TO ashutoshrai;

--
-- Name: user_academic_settings; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.user_academic_settings (
    user_id character varying(50) NOT NULL,
    min_attendance_percent integer DEFAULT 75,
    internal_marks_total integer DEFAULT 60,
    external_marks_total integer DEFAULT 40,
    internal_breakdown jsonb NOT NULL,
    external_breakdown jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT user_academic_settings_external_marks_total_check CHECK ((external_marks_total > 0)),
    CONSTRAINT user_academic_settings_internal_marks_total_check CHECK ((internal_marks_total > 0)),
    CONSTRAINT user_academic_settings_min_attendance_percent_check CHECK (((min_attendance_percent >= 50) AND (min_attendance_percent <= 100)))
);


ALTER TABLE public.user_academic_settings OWNER TO ashutoshrai;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.user_profiles (
    user_id character varying(50) NOT NULL,
    student_name character varying(150) NOT NULL,
    program character varying(150),
    cohort character varying(100),
    batch character varying(50),
    semester character varying(50),
    sprint character varying(50),
    academic_year character varying(50),
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_profiles OWNER TO ashutoshrai;

--
-- Name: user_timetable_entries; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.user_timetable_entries (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    specific_date date NOT NULL,
    day_of_week integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    slot_type character varying(30) NOT NULL,
    subject_id character varying(50),
    faculty_id character varying(50),
    classroom character varying(100),
    is_holiday boolean DEFAULT false,
    is_rescheduled boolean DEFAULT false,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_user_entry_duration_matches CHECK ((round((EXTRACT(epoch FROM (end_time - start_time)) / (60)::numeric)) = (duration_minutes)::numeric)),
    CONSTRAINT chk_user_entry_time_order CHECK ((end_time > start_time)),
    CONSTRAINT user_timetable_entries_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT user_timetable_entries_duration_minutes_check CHECK (((duration_minutes >= 15) AND (duration_minutes <= 480))),
    CONSTRAINT user_timetable_entries_slot_type_check CHECK (((slot_type)::text = ANY ((ARRAY['lecture'::character varying, 'lunch_break'::character varying, 'short_break'::character varying, 'free_period'::character varying, 'unassigned'::character varying, 'independent_study'::character varying])::text[])))
);


ALTER TABLE public.user_timetable_entries OWNER TO ashutoshrai;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ashutoshrai
--

CREATE TABLE public.users (
    id character varying(50) NOT NULL,
    email character varying(150) NOT NULL,
    full_name character varying(150) NOT NULL,
    role character varying(30) DEFAULT 'student'::character varying,
    cohort_id character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['student'::character varying, 'admin'::character varying, 'guest'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO ashutoshrai;

--
-- Name: attendance_audit_log id; Type: DEFAULT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.attendance_audit_log ALTER COLUMN id SET DEFAULT nextval('public.attendance_audit_log_id_seq'::regclass);


--
-- Name: document_ingestion_anomalies id; Type: DEFAULT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.document_ingestion_anomalies ALTER COLUMN id SET DEFAULT nextval('public.document_ingestion_anomalies_id_seq'::regclass);


--
-- Name: migration_staged_records id; Type: DEFAULT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.migration_staged_records ALTER COLUMN id SET DEFAULT nextval('public.migration_staged_records_id_seq'::regclass);


--
-- Data for Name: ai_conversations; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.ai_conversations (id, user_id, subject_id, title, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_messages; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.ai_messages (id, conversation_id, role, content, sources, created_at) FROM stdin;
\.


--
-- Data for Name: attendance_audit_log; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.attendance_audit_log (id, user_id, lecture_id, subject_id, previous_status, new_status, reason, changed_at) FROM stdin;
\.


--
-- Data for Name: classrooms; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.classrooms (id, name, building, capacity) FROM stdin;
\.


--
-- Data for Name: cohorts; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.cohorts (id, institution_id, name, program, batch, semester, sprint, created_at) FROM stdin;
\.


--
-- Data for Name: curriculum_modules; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.curriculum_modules (id, subject_id, unit_number, title, hours, created_at) FROM stdin;
\.


--
-- Data for Name: curriculum_subjects; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.curriculum_subjects (id, code, name, total_hours, credits, default_faculty_id, course_type, cohort_id, description, official_doc_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: curriculum_topics; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.curriculum_topics (id, module_id, subject_id, title, created_at) FROM stdin;
\.


--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.document_chunks (id, document_id, chunk_index, page_number, sheet_name, section_heading, content_text, token_count, created_at) FROM stdin;
\.


--
-- Data for Name: document_ingestion_anomalies; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.document_ingestion_anomalies (id, document_id, subject_id, field_name, extracted_value, expected_value, severity, resolution_status, notes, created_at) FROM stdin;
\.


--
-- Data for Name: faculty; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.faculty (id, name, title, email, phone, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: institutions; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.institutions (id, name, short_code, campus, academic_year, created_at) FROM stdin;
\.


--
-- Data for Name: lectures; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.lectures (id, user_id, date, subject_id, title, faculty_id, faculty_name, start_time, end_time, duration_minutes, status, classroom, notes, what_i_learned, important_concepts, examples_or_code, doubts_or_questions, homework_or_followup, confidence_rating, needs_revision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migration_staged_records; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.migration_staged_records (id, user_id, entity_type, entity_id, current_record, incoming_record, field_conflicts, status, created_at) FROM stdin;
\.


--
-- Data for Name: official_documents; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.official_documents (id, title, filename, file_type, file_size, file_hash, url, file_path, subject_id, tags, is_master_plan, extraction_status, extractor_version, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: official_timetable_templates; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.official_timetable_templates (id, cohort_id, day_of_week, start_time, end_time, duration_minutes, slot_type, subject_id, faculty_id, classroom, notes, created_at) FROM stdin;
\.


--
-- Data for Name: quiz_attempts; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.quiz_attempts (id, user_id, quiz_id, score, total_questions, answers, completed_at) FROM stdin;
\.


--
-- Data for Name: quizzes; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.quizzes (id, subject_id, topic_id, title, questions, created_at) FROM stdin;
\.


--
-- Data for Name: revision_sessions; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.revision_sessions (id, user_id, date, subject_id, topic_id, topic_title, duration_minutes, confidence_after, notes, created_at) FROM stdin;
\.


--
-- Data for Name: student_documents; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.student_documents (id, user_id, title, filename, file_type, file_size, file_hash, subject_id, file_path, tags, created_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.tasks (id, user_id, title, description, subject_id, deadline, priority, status, assessment_category, estimated_hours, actual_hours, resource_url, submission_url, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: topic_learning_progress; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.topic_learning_progress (user_id, topic_id, subject_id, status, confidence_rating, needs_revision, next_revision_date, personal_notes, questions_to_ask, last_revised_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_academic_settings; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.user_academic_settings (user_id, min_attendance_percent, internal_marks_total, external_marks_total, internal_breakdown, external_breakdown, updated_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.user_profiles (user_id, student_name, program, cohort, batch, semester, sprint, academic_year, updated_at) FROM stdin;
\.


--
-- Data for Name: user_timetable_entries; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.user_timetable_entries (id, user_id, specific_date, day_of_week, start_time, end_time, duration_minutes, slot_type, subject_id, faculty_id, classroom, is_holiday, is_rescheduled, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ashutoshrai
--

COPY public.users (id, email, full_name, role, cohort_id, created_at) FROM stdin;
\.


--
-- Name: attendance_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ashutoshrai
--

SELECT pg_catalog.setval('public.attendance_audit_log_id_seq', 1, false);


--
-- Name: document_ingestion_anomalies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ashutoshrai
--

SELECT pg_catalog.setval('public.document_ingestion_anomalies_id_seq', 1, false);


--
-- Name: migration_staged_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ashutoshrai
--

SELECT pg_catalog.setval('public.migration_staged_records_id_seq', 1, false);


--
-- Name: ai_conversations ai_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_pkey PRIMARY KEY (id);


--
-- Name: ai_messages ai_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_pkey PRIMARY KEY (id);


--
-- Name: attendance_audit_log attendance_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.attendance_audit_log
    ADD CONSTRAINT attendance_audit_log_pkey PRIMARY KEY (id);


--
-- Name: classrooms classrooms_name_key; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_name_key UNIQUE (name);


--
-- Name: classrooms classrooms_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_pkey PRIMARY KEY (id);


--
-- Name: cohorts cohorts_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.cohorts
    ADD CONSTRAINT cohorts_pkey PRIMARY KEY (id);


--
-- Name: curriculum_modules curriculum_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_modules
    ADD CONSTRAINT curriculum_modules_pkey PRIMARY KEY (id);


--
-- Name: curriculum_subjects curriculum_subjects_code_key; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_subjects
    ADD CONSTRAINT curriculum_subjects_code_key UNIQUE (code);


--
-- Name: curriculum_subjects curriculum_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_subjects
    ADD CONSTRAINT curriculum_subjects_pkey PRIMARY KEY (id);


--
-- Name: curriculum_topics curriculum_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_topics
    ADD CONSTRAINT curriculum_topics_pkey PRIMARY KEY (id);


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);


--
-- Name: document_ingestion_anomalies document_ingestion_anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.document_ingestion_anomalies
    ADD CONSTRAINT document_ingestion_anomalies_pkey PRIMARY KEY (id);


--
-- Name: faculty faculty_name_key; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT faculty_name_key UNIQUE (name);


--
-- Name: faculty faculty_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.faculty
    ADD CONSTRAINT faculty_pkey PRIMARY KEY (id);


--
-- Name: institutions institutions_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_pkey PRIMARY KEY (id);


--
-- Name: institutions institutions_short_code_key; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.institutions
    ADD CONSTRAINT institutions_short_code_key UNIQUE (short_code);


--
-- Name: lectures lectures_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.lectures
    ADD CONSTRAINT lectures_pkey PRIMARY KEY (id);


--
-- Name: migration_staged_records migration_staged_records_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.migration_staged_records
    ADD CONSTRAINT migration_staged_records_pkey PRIMARY KEY (id);


--
-- Name: official_documents official_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.official_documents
    ADD CONSTRAINT official_documents_pkey PRIMARY KEY (id);


--
-- Name: official_timetable_templates official_timetable_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.official_timetable_templates
    ADD CONSTRAINT official_timetable_templates_pkey PRIMARY KEY (id);


--
-- Name: quiz_attempts quiz_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_pkey PRIMARY KEY (id);


--
-- Name: quizzes quizzes_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_pkey PRIMARY KEY (id);


--
-- Name: revision_sessions revision_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.revision_sessions
    ADD CONSTRAINT revision_sessions_pkey PRIMARY KEY (id);


--
-- Name: student_documents student_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.student_documents
    ADD CONSTRAINT student_documents_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: topic_learning_progress topic_learning_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.topic_learning_progress
    ADD CONSTRAINT topic_learning_progress_pkey PRIMARY KEY (user_id, topic_id);


--
-- Name: lectures uq_lecture_user_slot; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.lectures
    ADD CONSTRAINT uq_lecture_user_slot UNIQUE (user_id, date, subject_id, start_time);


--
-- Name: user_academic_settings user_academic_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_academic_settings
    ADD CONSTRAINT user_academic_settings_pkey PRIMARY KEY (user_id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: user_timetable_entries user_timetable_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_timetable_entries
    ADD CONSTRAINT user_timetable_entries_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_chunks_doc_page; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE INDEX idx_chunks_doc_page ON public.document_chunks USING btree (document_id, page_number);


--
-- Name: idx_lectures_user_date; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE INDEX idx_lectures_user_date ON public.lectures USING btree (user_id, date DESC);


--
-- Name: idx_lectures_user_subject; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE INDEX idx_lectures_user_subject ON public.lectures USING btree (user_id, subject_id);


--
-- Name: idx_tasks_user_deadline; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE INDEX idx_tasks_user_deadline ON public.tasks USING btree (user_id, deadline, status);


--
-- Name: idx_timetable_entries_date; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE INDEX idx_timetable_entries_date ON public.user_timetable_entries USING btree (user_id, specific_date);


--
-- Name: idx_timetable_templates_day; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE INDEX idx_timetable_templates_day ON public.official_timetable_templates USING btree (cohort_id, day_of_week);


--
-- Name: uq_user_timetable_slot; Type: INDEX; Schema: public; Owner: ashutoshrai
--

CREATE UNIQUE INDEX uq_user_timetable_slot ON public.user_timetable_entries USING btree (user_id, specific_date, start_time, COALESCE(classroom, 'UNASSIGNED'::character varying));


--
-- Name: user_timetable_entries trg_check_classroom_double_booking; Type: TRIGGER; Schema: public; Owner: ashutoshrai
--

CREATE TRIGGER trg_check_classroom_double_booking BEFORE INSERT OR UPDATE ON public.user_timetable_entries FOR EACH ROW EXECUTE FUNCTION public.check_classroom_double_booking();


--
-- Name: user_timetable_entries trg_check_user_timetable_overlap; Type: TRIGGER; Schema: public; Owner: ashutoshrai
--

CREATE TRIGGER trg_check_user_timetable_overlap BEFORE INSERT OR UPDATE ON public.user_timetable_entries FOR EACH ROW EXECUTE FUNCTION public.check_user_timetable_overlap();


--
-- Name: ai_conversations ai_conversations_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE SET NULL;


--
-- Name: ai_conversations ai_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_messages ai_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.ai_messages
    ADD CONSTRAINT ai_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.ai_conversations(id) ON DELETE CASCADE;


--
-- Name: attendance_audit_log attendance_audit_log_lecture_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.attendance_audit_log
    ADD CONSTRAINT attendance_audit_log_lecture_id_fkey FOREIGN KEY (lecture_id) REFERENCES public.lectures(id) ON DELETE CASCADE;


--
-- Name: attendance_audit_log attendance_audit_log_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.attendance_audit_log
    ADD CONSTRAINT attendance_audit_log_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: attendance_audit_log attendance_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.attendance_audit_log
    ADD CONSTRAINT attendance_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cohorts cohorts_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.cohorts
    ADD CONSTRAINT cohorts_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutions(id) ON DELETE CASCADE;


--
-- Name: curriculum_modules curriculum_modules_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_modules
    ADD CONSTRAINT curriculum_modules_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: curriculum_subjects curriculum_subjects_cohort_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_subjects
    ADD CONSTRAINT curriculum_subjects_cohort_id_fkey FOREIGN KEY (cohort_id) REFERENCES public.cohorts(id) ON DELETE CASCADE;


--
-- Name: curriculum_subjects curriculum_subjects_default_faculty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_subjects
    ADD CONSTRAINT curriculum_subjects_default_faculty_id_fkey FOREIGN KEY (default_faculty_id) REFERENCES public.faculty(id) ON DELETE SET NULL;


--
-- Name: curriculum_topics curriculum_topics_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_topics
    ADD CONSTRAINT curriculum_topics_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.curriculum_modules(id) ON DELETE CASCADE;


--
-- Name: curriculum_topics curriculum_topics_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.curriculum_topics
    ADD CONSTRAINT curriculum_topics_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: document_chunks document_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.official_documents(id) ON DELETE CASCADE;


--
-- Name: document_ingestion_anomalies document_ingestion_anomalies_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.document_ingestion_anomalies
    ADD CONSTRAINT document_ingestion_anomalies_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.official_documents(id) ON DELETE CASCADE;


--
-- Name: document_ingestion_anomalies document_ingestion_anomalies_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.document_ingestion_anomalies
    ADD CONSTRAINT document_ingestion_anomalies_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: lectures lectures_faculty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.lectures
    ADD CONSTRAINT lectures_faculty_id_fkey FOREIGN KEY (faculty_id) REFERENCES public.faculty(id) ON DELETE SET NULL;


--
-- Name: lectures lectures_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.lectures
    ADD CONSTRAINT lectures_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE RESTRICT;


--
-- Name: lectures lectures_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.lectures
    ADD CONSTRAINT lectures_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: migration_staged_records migration_staged_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.migration_staged_records
    ADD CONSTRAINT migration_staged_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: official_documents official_documents_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.official_documents
    ADD CONSTRAINT official_documents_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE SET NULL;


--
-- Name: official_timetable_templates official_timetable_templates_cohort_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.official_timetable_templates
    ADD CONSTRAINT official_timetable_templates_cohort_id_fkey FOREIGN KEY (cohort_id) REFERENCES public.cohorts(id) ON DELETE CASCADE;


--
-- Name: official_timetable_templates official_timetable_templates_faculty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.official_timetable_templates
    ADD CONSTRAINT official_timetable_templates_faculty_id_fkey FOREIGN KEY (faculty_id) REFERENCES public.faculty(id) ON DELETE SET NULL;


--
-- Name: official_timetable_templates official_timetable_templates_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.official_timetable_templates
    ADD CONSTRAINT official_timetable_templates_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE SET NULL;


--
-- Name: quiz_attempts quiz_attempts_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE CASCADE;


--
-- Name: quiz_attempts quiz_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: quizzes quizzes_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: revision_sessions revision_sessions_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.revision_sessions
    ADD CONSTRAINT revision_sessions_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: revision_sessions revision_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.revision_sessions
    ADD CONSTRAINT revision_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_documents student_documents_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.student_documents
    ADD CONSTRAINT student_documents_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE SET NULL;


--
-- Name: student_documents student_documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.student_documents
    ADD CONSTRAINT student_documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: topic_learning_progress topic_learning_progress_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.topic_learning_progress
    ADD CONSTRAINT topic_learning_progress_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE CASCADE;


--
-- Name: topic_learning_progress topic_learning_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.topic_learning_progress
    ADD CONSTRAINT topic_learning_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_academic_settings user_academic_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_academic_settings
    ADD CONSTRAINT user_academic_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_timetable_entries user_timetable_entries_faculty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_timetable_entries
    ADD CONSTRAINT user_timetable_entries_faculty_id_fkey FOREIGN KEY (faculty_id) REFERENCES public.faculty(id) ON DELETE SET NULL;


--
-- Name: user_timetable_entries user_timetable_entries_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_timetable_entries
    ADD CONSTRAINT user_timetable_entries_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.curriculum_subjects(id) ON DELETE SET NULL;


--
-- Name: user_timetable_entries user_timetable_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.user_timetable_entries
    ADD CONSTRAINT user_timetable_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_cohort_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ashutoshrai
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_cohort_id_fkey FOREIGN KEY (cohort_id) REFERENCES public.cohorts(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict f8ZEbBQeGTb3TzLWvVsH9xjfH62fSHQsc1jWGm1NPOM1CJDcnubUIcWgz3cBec5

